---
name: Default Template
about: The default template.
title: ''
labels: ''
assignees: ''

---

<!-- Put details of the issue here-->

<!-- Paste any errors or output between the triple back ticks below: -->
```

```
