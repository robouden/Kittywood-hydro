package me.retrodaredevil.solarthing.commands.packets.status;

import me.retrodaredevil.solarthing.packets.DocumentedPacketType;

public enum CommandStatusPacketType implements DocumentedPacketType {
	AVAILABLE_COMMANDS
}
