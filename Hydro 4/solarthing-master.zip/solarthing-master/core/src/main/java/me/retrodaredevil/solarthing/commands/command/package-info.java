/**
 * This package and subpackages represents {@link me.retrodaredevil.solarthing.commands.command.Command}s. A command is something that
 * can be sent and received. Because this package is very generic, what a command does or triggers is not defined.
 */
package me.retrodaredevil.solarthing.commands.command;
