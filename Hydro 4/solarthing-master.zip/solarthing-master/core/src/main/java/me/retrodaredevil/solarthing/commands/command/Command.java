package me.retrodaredevil.solarthing.commands.command;

public interface Command {
	String getCommandName();
}
