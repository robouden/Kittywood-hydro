/**
 * Annotations in here are used for many things. Some annotations may affect the runtime, others
 * are for documenting code.
 */
package me.retrodaredevil.solarthing.annotations;
