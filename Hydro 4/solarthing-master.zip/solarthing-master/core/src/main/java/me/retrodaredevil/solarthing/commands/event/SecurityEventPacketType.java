package me.retrodaredevil.solarthing.commands.event;

import me.retrodaredevil.solarthing.packets.DocumentedPacketType;

public enum SecurityEventPacketType implements DocumentedPacketType {
	ACCEPT,
	REJECT,
}
