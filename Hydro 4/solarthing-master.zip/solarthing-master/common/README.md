# `common` submodule
This module is used in the `client` and `graphql` programs. Code here won't be included in solarthing-android
