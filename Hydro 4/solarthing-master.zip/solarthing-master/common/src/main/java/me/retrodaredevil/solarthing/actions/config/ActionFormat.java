package me.retrodaredevil.solarthing.actions.config;

public enum ActionFormat {
	NOTATION_SCRIPT,
	RAW_JSON,
}
