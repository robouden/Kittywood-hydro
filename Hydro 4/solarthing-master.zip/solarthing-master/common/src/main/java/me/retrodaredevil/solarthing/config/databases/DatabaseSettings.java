package me.retrodaredevil.solarthing.config.databases;

public interface DatabaseSettings {
	DatabaseType getDatabaseType();
}
