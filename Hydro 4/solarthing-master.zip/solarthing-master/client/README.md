## "client" subproject
This project utilizes code in the `core` module to read data from an Outback MATE or Renogy Rover
and uploads that data to a database.

While running this 24/7, it is recommended to schedule automatic weekly restarts. You can use [add_weekly_restart.sh](../other/linux/add_weekly_restart.sh) for this.

Look into: http://ideaheap.com/2013/07/stopping-sd-card-corruption-on-a-raspberry-pi/

