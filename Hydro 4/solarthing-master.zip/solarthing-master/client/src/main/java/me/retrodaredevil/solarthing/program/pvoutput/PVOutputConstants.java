package me.retrodaredevil.solarthing.program.pvoutput;

import me.retrodaredevil.solarthing.annotations.UtilityClass;

@UtilityClass
public class PVOutputConstants {
	private PVOutputConstants() { throw new UnsupportedOperationException(); }
	public static final int SOLARTHING_TEAM_ID = 1528;
}
