/**
 * This package represents many different interfaces used for command line options for the main solarthing program.
 */
package me.retrodaredevil.solarthing.config.options;
