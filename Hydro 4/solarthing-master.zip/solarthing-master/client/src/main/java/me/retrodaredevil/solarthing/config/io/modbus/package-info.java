/**
 * Contains classes to represent dummy modbus IOs
 */
package me.retrodaredevil.solarthing.config.io.modbus;
