package me.retrodaredevil.action.node.expression.result;

public interface ExpressionResult {
}
