/**
 * Contains classes that are not essential to provide full functionality, but make implementing functionality much easier
 */
package me.retrodaredevil.action.node.convenient;
