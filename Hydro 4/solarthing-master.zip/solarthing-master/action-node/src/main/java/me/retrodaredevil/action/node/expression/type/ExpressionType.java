package me.retrodaredevil.action.node.expression.type;

public interface ExpressionType {
}
