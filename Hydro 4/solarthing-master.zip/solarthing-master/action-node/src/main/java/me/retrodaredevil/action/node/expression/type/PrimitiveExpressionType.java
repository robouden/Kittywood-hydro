package me.retrodaredevil.action.node.expression.type;

public enum PrimitiveExpressionType implements ExpressionType {
	NUMERIC,
	STRING,
	BOOLEAN,
	;
}
