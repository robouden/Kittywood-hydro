# Action Node
This folder contains a module (code) relating to the action node library built upon action-lib
